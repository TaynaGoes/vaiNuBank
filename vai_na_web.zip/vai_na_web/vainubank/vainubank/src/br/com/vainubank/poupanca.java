package br.com.vainubank;

public class poupanca extends Conta {
    private double aniversario;

    public poupanca(Cliente cliente, double aniversario) {
        super(cliente);
        this.setAniversario(aniversario);
    }

    @Override
    public void sacar(double valor) {
        if (this.getSaldo() >= valor) {
            double juros = valor * 0.02;
            this.setSaldo(this.getSaldo() - valor - juros);
            System.out.println("Saque realizado");
        } else { System.err.println("falha na operação"); }
    }

	public double getAniversario() { return aniversario; }

	public void setAniversario(double aniversario) { this.aniversario = aniversario; }
}
