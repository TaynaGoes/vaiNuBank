package br.com.vainubank;

public class cliente {
	public static int count= 1;
	
	private String nomeCliente;
	private String cpfCliente;
	private String emailCliente;
	
	public Cliente(String nomeCliente, String cpfCliente, String emailCliente) {
		this.nomeCliente = nomeCliente;
		this.cpfCliente = cpfCliente;
		this.emailCliente = emailCliente;
		count += 1;
	}
	
	public String getNome() { return nomeCliente; }

	public void setNome(String nomeCliente) { this.nomeCliente = nomeCliente; }
    
	public String getEmail() { return emailCliente; }

	public void setEmail(String emailCliente) { this.emailCliente = emailCliente; }

	public String getCpf() { return cpfCliente; }

	public void setCpf(String cpfCliente) { this.cpfCliente = cpfCliente; }

	public String toString() {
		return "\nNome: " + this.getNome() +
		"\nCPF " + this.getCpf() +
		"\nEmail " + this.getEmail();
	}
	
}
