package br.com.vainubank;
public class corrente extends Conta {
private double limiteCredito;

public corrente(Cliente cliente, double limiteCredito) {
     super(cliente);
     this.limiteCredito = limiteCredito;
}

 @Override
 public void sacar(double valor) {
    if (this.getSaldo() + this.limiteCredito >= valor) {
         this.setSaldo(this.getSaldo() - valor);
         System.out.println("Saque realizado");
    } else { System.err.println("Falha na operação"); }
 }
}